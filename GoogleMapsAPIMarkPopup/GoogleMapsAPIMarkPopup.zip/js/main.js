function initMap() {
    var markers = [];
    var infowindow;
    infoWindows = [];
    var mapOptions = {
        center: {
            lat: 26.8206,
            lng: 30.8025
        },
        zoom: 6
    };
    var map = new google.maps.Map(document.getElementById("map"), mapOptions);
    google.maps.event.addListener(map, 'click', function () {
        if (infowindow) {
            infowindow.close();
        }
    });

    google.maps.event.addListener(map, "click", function (event) {
        closeInfoWindows();
    });


    var places = [{
            hours: "9am-5pm",
            bio: "The monasteries of St. Anthony and St. Paul are the oldest Christian monasteries; they both date back to the 4th century AD, when monks began to settle at the foot of the Red Sea mountain of Galala Al-Qibliya, in hidden cliffs and caves. Both monasteries are considered as the holiest sites of the Coptic Church in Egypt. Located off the Zafarana Road leading to Beni Suef, some 70 km south from Ain Sukhna, 45 km from Hurghada City, the Monastery of St Anthony is a large complex encircled by high walls, including churches, chapels, a bakery, a garden ...",
            type: "Coptic-Egypt",
            url: "google.com",
            img: "STanthony.jpg",
            wikiLink: "googl.com",
            coords: {
                lat: 28.556259,
                lng: 33.974819
            },
            iconImage: "https://cdn.iconscout.com/icon/premium/png-256-thumb/cross-397-883862.png",
            name: "St Anthony Monastery"
        }, {
            hours: "9am-5pm",
            bio: "The monasteries of St. Anthony and St. Paul are the oldest Christian monasteries; they both date back to the 4th century AD, when monks began to settle at the foot of the Red Sea mountain of Galala Al-Qibliya, in hidden cliffs and caves. Both monasteries are considered as the holiest sites of the Coptic Church in Egypt. Located off the Zafarana Road leading to Beni Suef, some 70 km south from Ain Sukhna, 45 km from Hurghada City, the Monastery of St Anthony is a large complex encircled by high walls, including churches, chapels, a bakery, a garden ...",
            type: "old-cairo",
            url: "google.com",
            img: "oldCairo.jpg",
            wikiLink: "googl.com",
            coords: {
                lat: 28.556259,
                lng: 34.974819
            },
            iconImage: "https://cdn.iconscout.com/icon/premium/png-256-thumb/cross-397-883862.png",
            name: "Old Cairo"
        },
        {
            hours: "9am-5pm",
            bio: "Located approximately 50 km southwest of Alexandria, the small village-town of Abu-Mina is home to St. Mena (Mina) monastery. St Mena is believed to have fallen as a martyr in the early 4th century when the Roman Empire was persecuting Christians. A modern monastery has been built on the location of an ancient church, where the Saint remains are believed to be buried. A German archeological team has been working at Abu Mina since 1969. Buses depart regularly from Alexandria new station (Baheej Station), to Abu-Mina. After reaching Abu-Mina, yo",
            type: "Coptic-Egypt",
            url: "google.com",
            img: "stmina.jpg",
            wikiLink: "googl.com",
            coords: {
                lat: 29.81785,
                lng: 30.94858
            },
            iconImage: "https://cdn.iconscout.com/icon/premium/png-256-thumb/cross-397-883862.png",
            name: "St Mena Monastery"
        },
        {
            hours: "9am-5pm",
            bio: "Located at the heart of Islamic Cairo, the Al-Azhar complex, mosque and university, does not only house the oldest university in the world but it is also the place where the graduation black gowns originated from. The costume worn by students all around the world during their graduation seems to have been inspired by the flowing robes of the Islamic Scholars graduating from Al-Azhar. The University is now distributed between different buildings, but the mosque, founded by Jawhar al-Siqilly, the Fatimid conqueror of Egypt, in 970 is still a true ",
            type: "Islamic-Egypt",
            url: "google.com",
            img: "Al-Azhar.jpg",
            wikiLink: "googl.com",
            coords: {
                lat: 30.04636,
                lng: 31.26423
            },
            iconImage: "http://www.myiconfinder.com/uploads/iconsets/256-256-aa86326e76cb24783b33b64f72b54090-mosque.png",
            name: "Al-Azhar Mosque"
        },
        {
            hours: "9am-5pm",
            bio: "The Karnak Temple Complex, commonly known as Karnak, comprises a vast mix of decayed temples, chapels, pylons, and other buildings near Luxor, in Egypt.......",
            type: "Ancient-Egypt",
            url: "google.com",
            img: "Karnak.jpg",
            wikiLink: "googl.com",
            coords: {
                lat: 26.06996,
                lng: 32.08605
            },
            iconImage: "https://image.flaticon.com/icons/png/128/288/288934.png",
            name: "karnak temple"
        }
    ];
    //fixed nav
    const nav = document.querySelector('nav')
    const topOfNav = nav.offsetTop;
    var fiterData = function () {
        var categ = this.getAttribute("data-categ");
        if (categ != 'all') {
            filteredplaces = places.filter(place => place.type == categ);
        } else {
            filteredplaces = places;
        }
        document.getElementById("dataBox").innerHTML = '';
        clearMarkers(markers);
        buildGride(filteredplaces);
    };

    window.addEventListener('scroll', fixNav);

    function fixNav() {

        if (window.scrollY >= topOfNav) {
            document.body.classList.add('fixedNav');
        } else {
            document.body.classList.remove('fixedNav');

        }
    }
    //load all categoreis nav elements
    var fliterNavCards = document.getElementsByClassName("fliterNavCard");


    function buildGride(places) {
        places.forEach(place => {
            html = "";
            place.bio = place.bio.substring(0, 200) + '...';
            document.getElementById("dataBox").innerHTML += buildhtml(
                place.name,
                place.bio,
                place.type,
                place.url,
                place.hours,
                place.img, html
            );
            // return;
        });
        setMarkers(places)
    }

    function buildhtml(name, bio, type, url, hours, img, html) {
        html += '<div class="card" >';
        html +=
            '<img class="card-img-top" width="100%" src="img/' +
            img +
            '" alt="Card image cap">';
        html += '<div class="card-body">';
        html += '<h5 class="card-title">' + name + "</h5>";
        html += '<p class="card-text">' + bio + " </p>";
        html += '<a href="#" class="btn btn-primary">Read More...</a>';
        html += "</div>";
        html += "</div>";
        return html;
    }

    function setMarkers(places) {
        // add all mark for each place
        for (var i = 0; i < places.length; i++) {
            addMarkers(places[i]);
        }
    }

    buildGride(places)

    // https://developers.google.com/maps/documentation/javascript/markers

    function clearMarkers(markers) {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(null);
        }
    }

    //adding the event Listener
    for (var i = 0; i < fliterNavCards.length; i++) {
        fliterNavCards[i].addEventListener("click", fiterData);
    }

    function addMarkers(mark) {
        var marker = new google.maps.Marker({
            position: mark.coords,
            map: map,
            animation: google.maps.Animation.DROP
        });

        markers.push(marker);
        // Check for customicon
        if (mark.iconImage) {
            // Set icon image
            var icon = {
                url: mark.iconImage, // url
                scaledSize: new google.maps.Size(30, 30), // scaled size
                origin: new google.maps.Point(0, 0), // origin
                anchor: new google.maps.Point(0, 0) // anchor
            };
            marker.setIcon(icon);
        }
        // Check content
        if (mark.bio) {

            mark.bio = mark.bio.substring(0, 150) + '...';
            var contentString = '<div id="content">' +
                '<div id="siteNotice">' + '<img class="windoImg"  src="img/' + mark.img + '" alt="' + mark.name + '"></div>' +
                '<h3 id="firstHeading" class="firstHeading">' + mark.name + '</h3>' +
                '<div id="bodyContent">' +
                '<p>' + mark.bio + '</p><a href="' + mark.wikiLink + '" >' +
                'Read More wikipedia.org....</a>' +
                '</div>' +
                '</div>';

            var infoWindow = new google.maps.InfoWindow({
                content: contentString
            });
            infoWindows.push(infoWindow)
            marker.addListener('click', function () {
                closeInfoWindows();
                infoWindow.open(map, marker);
            });
        }

    }

    function closeInfoWindows() {
        for (var i = 0; i < infoWindows.length; i++) {
            infoWindows[i].close();
        }
    }

}